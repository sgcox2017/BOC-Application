/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author aenamenye2018
 */
@Entity
@Table(name = "Question")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Question.findAll", query = "SELECT q FROM Question q"),
    @NamedQuery(name = "Question.findByQuestionID", query = "SELECT q FROM Question q WHERE q.questionID = :questionID"),
    @NamedQuery(name = "Question.findByCategory", query = "SELECT q FROM Question q WHERE q.category = :category"),
    @NamedQuery(name = "Question.findByDifficulty", query = "SELECT q FROM Question q WHERE q.difficulty = :difficulty"),
    @NamedQuery(name = "Question.findByQuestionDescription", query = "SELECT q FROM Question q WHERE q.questionDescription = :questionDescription"),
    @NamedQuery(name = "Question.findByAnswer", query = "SELECT q FROM Question q WHERE q.answer = :answer"),
    @NamedQuery(name = "Question.findByOptionOne", query = "SELECT q FROM Question q WHERE q.optionOne = :optionOne"),
    @NamedQuery(name = "Question.findByOptionTwo", query = "SELECT q FROM Question q WHERE q.optionTwo = :optionTwo"),
    @NamedQuery(name = "Question.findByOptionThree", query = "SELECT q FROM Question q WHERE q.optionThree = :optionThree")})
public class Question implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "QuestionID")
    private Integer questionID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "Category")
    private String category;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "Difficulty")
    private String difficulty;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "QuestionDescription")
    private String questionDescription;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "Answer")
    private String answer;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "OptionOne")
    private String optionOne;
    @Size(max = 256)
    @Column(name = "OptionTwo")
    private String optionTwo;
    @Size(max = 256)
    @Column(name = "OptionThree")
    private String optionThree;

    public Question() {
    }

    public Question(Integer questionID) {
        this.questionID = questionID;
    }

    public Question(Integer questionID, String category, String difficulty, String questionDescription, String answer, String optionOne) {
        this.questionID = questionID;
        this.category = category;
        this.difficulty = difficulty;
        this.questionDescription = questionDescription;
        this.answer = answer;
        this.optionOne = optionOne;
    }

    public Integer getQuestionID() {
        return questionID;
    }

    public void setQuestionID(Integer questionID) {
        this.questionID = questionID;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getQuestionDescription() {
        return questionDescription;
    }

    public void setQuestionDescription(String questionDescription) {
        this.questionDescription = questionDescription;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getOptionOne() {
        return optionOne;
    }

    public void setOptionOne(String optionOne) {
        this.optionOne = optionOne;
    }

    public String getOptionTwo() {
        return optionTwo;
    }

    public void setOptionTwo(String optionTwo) {
        this.optionTwo = optionTwo;
    }

    public String getOptionThree() {
        return optionThree;
    }

    public void setOptionThree(String optionThree) {
        this.optionThree = optionThree;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (questionID != null ? questionID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Question)) {
            return false;
        }
        Question other = (Question) object;
        if ((this.questionID == null && other.questionID != null) || (this.questionID != null && !this.questionID.equals(other.questionID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Question[ questionID=" + questionID + " ]";
    }
    
}
