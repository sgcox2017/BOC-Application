/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entities.Player;
import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aenamenye2018
 */
@Stateless
@WebService
public class PlayerFacade extends AbstractFacade<Player> {
    @PersistenceContext(unitName = "BOCEJBPU")
    private EntityManager em;
    private Player plr;
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlayerFacade() {
        super(Player.class);
    }
    
    public Player getPlayer(String username){
        
        return super.find(username);
        
        
    }
    
    public void deletePlayer(String username){
        
        plr = super.find(username);
        super.remove(plr);
        
    }
    
    public void createPlayer(String username, String password, String secQuestion, String secAnswer){
        
        plr = new Player(username);
        plr.setPassword(password);
        plr.setSecQuestion(secQuestion);
        plr.setSecAnswer(secAnswer);
        super.create(plr);
        
    }
    
    public void updatePlayer (String username, String password, String secQuestion, String secAnswer){
        
        plr = new Player(username);
        plr.setPassword(password);
        plr.setSecQuestion(secQuestion);
        plr.setSecAnswer(secAnswer);
        super.edit(plr);
        
        
    }
}
