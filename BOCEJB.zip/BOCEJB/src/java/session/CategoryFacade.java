/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entities.Category;
import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aenamenye2018
 */
@Stateless
@WebService
public class CategoryFacade extends AbstractFacade<Category> {
    @PersistenceContext(unitName = "BOCEJBPU")
    private EntityManager em;
    private Category Ca;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CategoryFacade() {
        super(Category.class);
    }
    
    public Category findCat (int CategoryID){
        
        return super.find(CategoryID);
        
    }
    
    
    public void updateCat (int CategoryID,  String CategoryName){
        
        Ca = new Category(CategoryID);
        Ca.setCategoryName(CategoryName);
        super.edit(Ca);
        
    }
    
    public void createCat (int CategoryID,  String CategoryName){
        
        Ca = new Category(CategoryID);
        Ca.setCategoryName(CategoryName);
        super.create(Ca);
        
    }
    
    public void deleteCat(int CategoryID){
        Ca = super.find(CategoryID);
        super.remove(Ca);
        
        
    }
    
}
