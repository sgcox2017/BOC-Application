/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entities.PlayerStatistics;
import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aenamenye2018
 */
@Stateless
@WebService
public class PlayerStatisticsFacade extends AbstractFacade<PlayerStatistics> {
    @PersistenceContext(unitName = "BOCEJBPU")
    private EntityManager em;
    private PlayerStatistics ps;
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlayerStatisticsFacade() {
        super(PlayerStatistics.class);
    }
    
    public PlayerStatistics getPlayerStats(String userId){
        
        return super.find(userId); 
        
    }
    
    public void removePlayerStats (String UserId){
        ps = super.find(UserId);
        super.remove(ps);
     
        
    }
    
    public void createPlayerStats(String userId, int QuestionID, String Category, String Difficulty, String AnsweredCorrectly, int points){
        
        ps = new PlayerStatistics(userId);
        ps.setQuestionID(QuestionID);
        ps.setCategory(Category);
        ps.setDifficulty(Difficulty);
        ps.setAnsweredCorrectly(AnsweredCorrectly);
        ps.setPoints(points);
        super.create(ps);
        
}
    
      public void updatePlayerStats(String userId, int QuestionID, String Category, String Difficulty, String AnsweredCorrectly, int points){
        
        ps = new PlayerStatistics(userId);
        ps.setQuestionID(QuestionID);
        ps.setCategory(Category);
        ps.setDifficulty(Difficulty);
        ps.setAnsweredCorrectly(AnsweredCorrectly);
        ps.setPoints(points);
        super.edit(ps);
        
}  
    
}
