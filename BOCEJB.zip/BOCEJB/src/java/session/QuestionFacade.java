/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entities.Question;
import javax.ejb.Stateless;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author aenamenye2018
 */
@Stateless
@WebService
public class QuestionFacade extends AbstractFacade<Question> {
    @PersistenceContext(unitName = "BOCEJBPU")
    private EntityManager em;
    private Question Qa;
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public QuestionFacade() {
        super(Question.class);
    }
    
    public Question getQuestion(int QuestionId){
        
        return super.find(QuestionId);
        
    }
    
    public void deleteQuestion(int QuestionId){
        Qa = super.find(QuestionId);
        super.remove(Qa);
    }
    
    public void createQuestion (int QuestionId, String Category, String Difficulty, String QuestionDescription, String Answer, String OptionOne, String OptionTwo, String OptionThree){
        
        Qa = new Question(QuestionId);
        Qa.setCategory(Category);
        Qa.setDifficulty(Difficulty);
        Qa.setQuestionDescription(QuestionDescription);
        Qa.setAnswer(Answer);
        Qa.setOptionOne(OptionOne);
        Qa.setOptionTwo(OptionTwo);
        Qa.setOptionThree(OptionThree);
        super.create(Qa);
    }
    
    public void updateQuestion(int QuestionId, String Category, String Difficulty, String QuestionDescription, String Answer, String OptionOne, String OptionTwo, String OptionThree){
        
        
        
        Qa = new Question(QuestionId);
        Qa.setCategory(Category);
        Qa.setDifficulty(Difficulty);
        Qa.setQuestionDescription(QuestionDescription);
        Qa.setAnswer(Answer);
        Qa.setOptionOne(OptionOne);
        Qa.setOptionTwo(OptionTwo);
        Qa.setOptionThree(OptionThree);
        super.edit(Qa);
        
    }
}
